export class EstatisticaUso {
  totalCampeonatosParticipados: number = 0;
  totalModalidadesInscritas: number = 0;
}
