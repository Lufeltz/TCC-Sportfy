export class Time {
  idTime: number = 0;
  nome: string = '';
  campeonato: number = 0;
  senhaCampeonato: string = '';
}
