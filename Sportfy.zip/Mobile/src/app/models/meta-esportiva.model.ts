export class MetaEsportiva {
  tipo: string = 'esportiva';
  idMetaEsportiva: number = 0;
  titulo: string = '';
  descricao: string = '';
  foto: null = null;
  idModalidadeEsportiva: number = 0;
}
