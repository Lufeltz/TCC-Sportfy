export class Usuario {
    idUsuario: number = 0;
    username: string = '';
    nome: string = '';
    foto: string | null = '';
    permissao: string = '';
  }