export class Endereco {
    cep: string = '';
    uf: string = '';
    cidade: string = '';
    bairro: string = '';
    rua: string = '';
    numero: number | null = null;
    complemento: string | null = null;
  }
  