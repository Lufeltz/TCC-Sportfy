export class Cadastro {
  curso: string = '';
  username: string = '';
  email: string = '';
  password: null = null;
  nome: string = '';
  telefone: string = '';
  dataNascimento: string = '';
  foto: null = null;
}
