export class LoginResponse {
    token: string = '';
}