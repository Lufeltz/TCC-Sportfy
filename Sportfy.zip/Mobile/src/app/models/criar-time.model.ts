export class CriarTime {
  nome: string = '';
  campeonato: number = 0;
  senhaCampeonato: string | null = '';
}
