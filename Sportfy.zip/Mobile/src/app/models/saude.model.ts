export class Saude {
    idApoioSaude: number = 0;
    nome: string = '';
    email: string = '';
    telefone: string = '';
    descricao: string = '';
    dataPublicacao: string = '';
    idAdministrador: number = 0;
    ativo: boolean = true;
}
