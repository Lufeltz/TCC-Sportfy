export class Privacidade {
  idAcademico: number = 0;
  mostrarModalidadesEsportivas: boolean = false;
  mostrarHistoricoCampeonatos: boolean = false;
  mostrarEstatisticasModalidadesEsportivas = false;
  mostrarConquistas = false;
}
