export class Avaliacao {
  mediaGeral: number = 0;
  quantidadeAvaliacoes: number = 0;
  quantidadeModalidadesAvaliadas: number = 0;
}
