export class Jogador {
  idJogador: number = 0;
  username: string = '';
  idModalidadeEsportiva: number = 0;
  situacaoJogador: string = '';
  pontuacao: number = 0;
  idTime: number = 0;
  idAcademico: number = 0;
}
