import AuthPage from './auth/page'

export default function Home() {
  return <AuthPage />
}
