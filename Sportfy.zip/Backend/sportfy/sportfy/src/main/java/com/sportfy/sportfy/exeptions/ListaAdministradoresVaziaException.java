package com.sportfy.sportfy.exeptions;

public class ListaAdministradoresVaziaException extends Exception{
    public ListaAdministradoresVaziaException(String mensagem){
        super(mensagem);
    }
}
