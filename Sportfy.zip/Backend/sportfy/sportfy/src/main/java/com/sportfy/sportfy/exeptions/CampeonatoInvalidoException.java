package com.sportfy.sportfy.exeptions;

public class CampeonatoInvalidoException extends Exception{
    public CampeonatoInvalidoException(String mensagem){
            super(mensagem);
        }

}
