package com.sportfy.sportfy.exeptions;

public class UsuarioCurtidaComentarioNaoExisteException extends Exception{
    public UsuarioCurtidaComentarioNaoExisteException(String mensagem){
        super(mensagem);
    }
}
