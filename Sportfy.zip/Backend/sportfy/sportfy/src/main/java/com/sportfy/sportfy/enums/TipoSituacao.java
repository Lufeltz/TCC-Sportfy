package com.sportfy.sportfy.enums;

public enum TipoSituacao {
    EM_ABERTO,
    INICIADO,
    FINALIZADO,
}
