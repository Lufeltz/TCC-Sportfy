package com.sportfy.sportfy.exeptions;

public class InscricaoEmModalidadeNaoExisteException extends Exception{
    public InscricaoEmModalidadeNaoExisteException(String mensagem){
        super(mensagem);
    }
}
