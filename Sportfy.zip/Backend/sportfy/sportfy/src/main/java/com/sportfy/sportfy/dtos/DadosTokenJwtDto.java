package com.sportfy.sportfy.dtos;

public record DadosTokenJwtDto(String token) {
}
