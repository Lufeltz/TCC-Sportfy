package com.sportfy.sportfy.exeptions;

public class ConquistaNaoExistenteException extends Exception{
    public ConquistaNaoExistenteException(String mensagem){
        super(mensagem);
    }
}
