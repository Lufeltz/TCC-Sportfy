package com.sportfy.sportfy.exeptions;

public class ListaCanalVazioException extends Exception{
    public ListaCanalVazioException(String mensagem){
        super(mensagem);
    }
}
