package com.sportfy.sportfy.exeptions;

public class AvancarFaseException extends Exception{
    public AvancarFaseException(String mensagem){
        super(mensagem);
    }
}
