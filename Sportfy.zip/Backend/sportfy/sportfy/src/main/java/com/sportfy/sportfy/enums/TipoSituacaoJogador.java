package com.sportfy.sportfy.enums;

public enum TipoSituacaoJogador {
    EM_ABERTO,
    ATIVO,
    BLOQUEADO,
    FINALIZADO,
}
