package com.sportfy.sportfy.exeptions;

public class PasswordInvalidoException extends Exception{
    public PasswordInvalidoException(String mensagem){
        super(mensagem);
    }
}
