package com.sportfy.sportfy.exeptions;

public class ModalidadeNaoExistenteException extends Exception{
    public ModalidadeNaoExistenteException(String mensagem){
        super(mensagem);
    }
}
