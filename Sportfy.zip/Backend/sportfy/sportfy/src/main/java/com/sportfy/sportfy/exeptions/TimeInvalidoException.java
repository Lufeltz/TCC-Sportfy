package com.sportfy.sportfy.exeptions;

public class TimeInvalidoException extends Exception{
    public TimeInvalidoException(String mensagem){
        super(mensagem);
    }
}
