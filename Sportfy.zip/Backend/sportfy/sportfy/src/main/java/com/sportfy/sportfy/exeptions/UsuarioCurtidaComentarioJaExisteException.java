package com.sportfy.sportfy.exeptions;

public class UsuarioCurtidaComentarioJaExisteException extends Exception{
    public UsuarioCurtidaComentarioJaExisteException(String mensagem){
        super(mensagem);
    }
}
