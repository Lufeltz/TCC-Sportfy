package com.sportfy.sportfy.exeptions;

public class TipoInvalidoException extends Exception{
        public TipoInvalidoException(String mensagem){
            super(mensagem);
        }

}
