package com.sportfy.sportfy.enums;

public enum TipoSituacaoMetaDiaria {
    EM_ANDAMENTO,
    CONCLUIDA,
}
