package com.sportfy.sportfy.exeptions;

public class ConteudoPrivadoException extends Exception{
    public ConteudoPrivadoException(String mensagem){
        super(mensagem);
    }
}
