package com.sportfy.sportfy.dtos;

public record TimeDto( Long idTime, String nome, Long campeonato, String senhaCampeonato){
}
