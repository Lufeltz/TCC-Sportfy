package com.sportfy.sportfy.dtos;

public record MediaAvaliacaoDto(double mediaGeral, int quantidadeAvaliacoes, int quantidadeModalidadesAvaliadas
) {
}

