package com.sportfy.sportfy.exeptions;

public class MetaDiariaNaoExistenteException extends Exception{
    public MetaDiariaNaoExistenteException(String mensagem){
        super(mensagem);
    }
}
