package com.sportfy.sportfy.exeptions;

public class CepInvalidoException extends Exception{
    public CepInvalidoException(String mensagem){
        super(mensagem);
    }
}
