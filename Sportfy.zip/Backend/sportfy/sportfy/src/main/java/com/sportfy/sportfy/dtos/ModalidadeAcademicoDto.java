package com.sportfy.sportfy.dtos;

public record ModalidadeAcademicoDto (Long idModalidade, String nomeModalidade){
}
