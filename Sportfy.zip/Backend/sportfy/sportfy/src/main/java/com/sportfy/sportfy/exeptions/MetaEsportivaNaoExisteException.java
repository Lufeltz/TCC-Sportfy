package com.sportfy.sportfy.exeptions;

public class MetaEsportivaNaoExisteException extends Exception{
    public MetaEsportivaNaoExisteException(String mensagem){
        super(mensagem);
    }
}
