package com.sportfy.sportfy.exeptions;

public class ModalidadeJaExisteException extends Exception{
    public ModalidadeJaExisteException(String mensagem){
        super(mensagem);
    }
}
