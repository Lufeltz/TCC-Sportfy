package com.sportfy.sportfy.enums;

public enum TipoCanal {
    COMUNIDADE,
}
