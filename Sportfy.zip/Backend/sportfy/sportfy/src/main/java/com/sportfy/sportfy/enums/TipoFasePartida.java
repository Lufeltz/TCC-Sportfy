package com.sportfy.sportfy.enums;

public enum TipoFasePartida {
    PRIMEIRA_FASE,
    OITAVAS,
    QUARTAS,
    SEMI,
    FINAL
}
