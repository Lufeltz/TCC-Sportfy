package com.sportfy.sportfy.enums;

public enum TipoPrivacidadeCampeonato {
    PUBLICO,
    PRIVADO,
}
