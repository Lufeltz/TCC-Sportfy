package com.sportfy.sportfy.dtos;

public record AvaliacaoResponseDto( float media, int quantidadeAvaliacoes
) {
}

