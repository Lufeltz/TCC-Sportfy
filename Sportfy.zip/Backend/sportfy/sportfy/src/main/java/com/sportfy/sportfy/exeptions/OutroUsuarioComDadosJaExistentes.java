package com.sportfy.sportfy.exeptions;

public class OutroUsuarioComDadosJaExistentes extends Exception{
    public OutroUsuarioComDadosJaExistentes(String mensagem){
        super(mensagem);
    }
}
