package com.sportfy.sportfy.exeptions;

public class ListaAcademicosVaziaException extends Exception{
    public ListaAcademicosVaziaException(String mensagem){
        super(mensagem);
    }
}
