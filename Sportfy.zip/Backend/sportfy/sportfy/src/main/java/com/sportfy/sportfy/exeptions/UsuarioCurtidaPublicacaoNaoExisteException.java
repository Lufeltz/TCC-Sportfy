package com.sportfy.sportfy.exeptions;

public class UsuarioCurtidaPublicacaoNaoExisteException extends Exception{
    public UsuarioCurtidaPublicacaoNaoExisteException(String mensagem){
        super(mensagem);
    }
}
