package com.sportfy.sportfy.exeptions;

public class UsuarioCurtidaPublicacaoJaExisteException extends Exception{
    public UsuarioCurtidaPublicacaoJaExisteException(String mensagem){
        super(mensagem);
    }
}
