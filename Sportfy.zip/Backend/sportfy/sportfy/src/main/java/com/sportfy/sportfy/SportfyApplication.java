package com.sportfy.sportfy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportfyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SportfyApplication.class, args);
	}

}
