package com.sportfy.sportfy.exeptions;

public class EmailInvalidoException extends Exception{
    public EmailInvalidoException(String mensagem){
        super(mensagem);
    }
}
