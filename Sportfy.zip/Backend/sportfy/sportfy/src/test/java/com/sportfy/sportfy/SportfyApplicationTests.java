package com.sportfy.sportfy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportfyApplicationTests {

	@Test
	void contextLoads() {
	}

}
